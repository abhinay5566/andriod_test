package com.example.macstudent.myapplication;

/**
 * Created by macstudent on 2017-04-22.
 */

public class MyModel {

    String receipename;
    String description;

    int imgID;

    public  MyModel(){


    }


}
