package com.example.macstudent.myapplication;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by macstudent on 2017-04-22.
 */

public class tab1 extends Fragment {

    ListView myListView;
    ArrayList<MyModel> myList = new ArrayList<MyModel>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.tabone, container, false);
        myListView = (ListView) view.findViewById(R.id.myListViewID);

        MyModel ob1 = new MyModel();
        ob1.receipename = "tandori";
        ob1.imgID = R.drawable.tandori;
        ob1.description = "We would like to present you with the recipe for our favourite curry on Mongolian Kitchen. The tandoori chicken Massala, also very similar to our vegetable tikka";
        myList.add(ob1);

        MyModel ob2 = new MyModel();

        ob2.receipename = "mutton";
        ob2.imgID = R.drawable.mutton;
        ob2.description = "Mutton curry recipe or mutton masala gravy recipe – Delicious, soft tender chunks of lamb meat in Indian style spiced onion tomato gravy. ... I had numerous requests from readers for a good mutton curry recipe. ... Mutton curry recipe or mutton masala - lamb meat cooked in Indian style .";
        myList.add(ob2);


        MyModel ob3 = new MyModel();

        ob3.receipename = "fish";
        ob3.imgID = R.drawable.fish;
        ob3.description = "Fish curry recipe with step by step photos. Simple Indian fish curry made with basic ingredients, goes good with rice or chapathi.";
        myList.add(ob3);


        MyModel ob4 = new MyModel();

        ob4.receipename = "allu";
        ob4.imgID = R.drawable.allu;
        ob4.description = "Potato curry or aloo curry recipe with step by step photos. ... This aloo curry goes very well with chapathi, rice, pulao or dosa. ... The same recipe can be used to make a dry potato curry or a potato gravy curry.";
        myList.add(ob4);


        MyModel ob5 = new MyModel();
        ob5.receipename = "shrimp";
        ob5.imgID = R.drawable.shrimp;
        ob5.description = "Stir in curry powder and chiles and cook, stirring frequently, 2 minutes. Stir in water, coconut milk, and lime juice and simmer, stirring occasionally, until thickened, 5 to 8 minutes. While sauce simmers, peel shrimp (devein if desired) and season with salt and pepper.";
        myList.add(ob5);


        MyModel ob6 = new MyModel();
        ob6.receipename = "bendi";
        ob6.imgID = R.drawable.bendi;
        ob6.description = "add the sauteed bhindi (okra). stir again. bring the bhindi masala curry to a simmer on a medium flame. cook for about 5 to 6 minutes till the gravy get infused with the aroma and flavor of the okra";
        myList.add(ob6);



        MyModel ob7 = new MyModel();
        ob7.receipename = "cucumber";
        ob7.imgID = R.drawable.cucumber;
        ob7.description = "How to make Cucumber Curry -Creaminess of coconut milk and crunch of peanuts make this cucumber dish a must have.";
        myList.add(ob7);




        MyModel ob8 = new MyModel();
        ob8.receipename = "    tamato";
        ob8.imgID = R.drawable.tamato;
        ob8.description = "Add oil to a pan and heat it. Add cumin and mustard, when they begin to sizzle add curry leaves, green chili and hing. Add chopped onions, salt and fry lightly till they turn pink. Add the chopped tomatoes, turmeric";
        myList.add(ob8);



        MyModel ob9 = new MyModel();
        ob9.receipename = "egg";
        ob9.imgID = R.drawable.egg;
        ob9.description = "Punjabi egg curry recipe with step by step photos. Made in dhaba style, it is exceptionally good when you are not in a mood to cook something elaborate";
        myList.add(ob9);


        CustomAdapter myAdapter = new CustomAdapter(myList, getContext());

        myListView.setAdapter(myAdapter);

        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {
                Intent intent = new Intent(getActivity(), details_Activity.class);

                //MyModel myModelInfo = (MyModel) parent.getItemAtPosition(position);

                MyModel myModelInfo = myList.get(position);
                String movieName = myModelInfo.receipename;
                String description = myModelInfo.description;
                intent.putExtra("receipeNameKey", movieName);
                intent.putExtra("receipeNameKey", description);


                startActivity(intent);
            }
        });

        return view;
    }
        }

