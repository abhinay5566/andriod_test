package com.example.macstudent.myapplication;

import io.realm.RealmObject;

/**
 * Created by macstudent on 2017-04-25.
 */

public class helper extends RealmObject {
    String name;
    String email;
    String age;
    String password;

}
